This package contains third-party software components governed by the license(s) indicated below:
---------

Autodesk FBX SDK. Copyright (c) 2018 Autodesk, Inc. All rights reserved. Use of the FBX SDK requires agreeing to and complying with the FBX SDK License and Service Agreement terms accessed at <https://oc.unity3d.com/index.php/s/Pb6ny5njyqp435N>.
