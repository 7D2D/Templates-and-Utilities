# Unity In App Purchasing

Implementation of the Unity In App Purchasing API.

## Release Notes

- Adding Readme file
- Adding local plugin importer callbacks.
- Removing Bintray references in package.json