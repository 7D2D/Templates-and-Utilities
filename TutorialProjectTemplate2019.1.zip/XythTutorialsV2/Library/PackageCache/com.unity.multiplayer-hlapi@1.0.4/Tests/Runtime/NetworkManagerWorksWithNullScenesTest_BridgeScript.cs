﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetworkManagerWorksWithNullScenesTest_BridgeScript : MonoBehaviour
{
    public const string bridgeGameObjectName = "NetworkManagerWorksWithNullScenesTest_BridgeScriptGO";

    public GameObject playerPrefab;
}
